# ReShoes Finance — Proyek Android (Siap Kompilasi APK)

Proyek ini membungkus dashboard keuangan **ReShoes Finance** (`app/src/main/assets/index.html`) ke dalam aplikasi Android WebView bertema Blue Navy (`#0B1E3D`).

## Cara Menghasilkan File `.apk`

### Opsi 1: Android Studio (Lokal)
1. Ekstrak file ZIP ini.
2. Buka folder `ReShoesFinanceAndroid` di **Android Studio**.
3. Tunggu Gradle Sync selesai, lalu pilih menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. File `.apk` akan muncul di `app/build/outputs/apk/debug/app-debug.apk` dan siap diinstal ke HP Android.

### Opsi 2: Tanpa Install Android Studio (GitHub Actions)
1. Unggah isi folder ini ke repositori GitHub Anda (branch `main`).
2. Buka tab **Actions** → pilih workflow **Build Android APK** → klik **Run workflow**.
3. Setelah selesai (~2 menit), unduh file `ReShoesFinance-debug-apk` yang berisi `app-debug.apk`.
